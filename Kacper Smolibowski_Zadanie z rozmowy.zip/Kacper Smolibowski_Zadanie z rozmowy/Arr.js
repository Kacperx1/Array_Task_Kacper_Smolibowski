
var x; // zmienna przechowuje wartość, która poda użytownik 
var y;// wartośc, którą podał użytkownik (po zmianie typu danych)
var array; // nazwa tablicy

function Error()  // funkcja ta sprawdza czy użytkownik nie podał wartości mniejszej od zera. Wartość może być tylko większa od zera.
{
	
if(x<0)
{
alert("Error, The value must be greater than zero!"); // okno dialogowe pojawi się z pewnym komunikatem jeżeli x będzie mniejszy od zera
          return false;
}

}


function GetValues() // funkcja ta pobiera wartość, którą podał użytkownik
{
	
x=document.getElementById("Value_of_Array").value; //pobranie wartości od użytkownika
y=parseInt(x); // zmiana typu danych
Error(); // wywołanie funkcji Error() 

 array=new Array(y); // tablica z liczbą elementów, którą poda użytkownik 

for(i=0;i<array.length;i++) //każdy element tablicy będzie miał losową wartość
{
array[i] = Math.floor(Math.random() * y) + 1; // wartości tablicy są losowe ilość elementów odpowiada ilości jaką poda użytkownik
}

}





function ShowItems() // funkcja ta wyświetli losowe liczby po kliknięciu "Show all items"
{	
GetValues(); // wywołanie funkcji GetValues()

document.getElementById("Elements").innerHTML=array; // wyświetlanie elementów w divie o id=Elements
		
}

function AscendingSort() // funkcja ta sortuje rosnąco wartości np 1,2,3...
{

GetValues(); // wywołanie funkcji GetValues()
array.sort(function(a, b){return a-b}); // funkcja sortowania, sprawdza różnice miedzy dwoma elementami a następnie odpowiednio sortuje .
// np a=5 b=6 więc 5-6=-1 oznacza to, że 5 jest < 6 więc najpierw wyświetli się mniejsza wartość.
document.getElementById("Elements").innerHTML=array;// wyświetlanie posortowanych elementów
}

function DescendingSort() // funkcja ta sortuje malejąco wartości np 10,9,8...
{
GetValues(); // wywłanie funkcji GetValues
array.sort(function(a, b){return b-a}); // funkcja sortowania, sprawdza różnice miedzy dwoma elementami a następnie odpowiednio sortuje.
//np 3,4 gdzie a=3 b=4 4-3=1 oznacza to, że 4 jest > 3 więc najpierw wyświetli się większa wartość 
document.getElementById("Elements").innerHTML=array;//wyświetlanie wyniku.

}




